<?php

namespace App\Http\Controllers;
use App\Models\pomodel;
use Illuminate\Http\Request;

class apiuserController extends Controller
{
    public function viewapi(Request $rq){
        $fdate=$rq->fromdate;
        $tdate=$rq->todate;
        $result=pomodel::where('date','>=',$fdate)
        ->where('date','<=',$tdate)
        ->get();
        return $result;
        // echo 1;
        //    return view('apiview.apirrach',['polist'=>$result]);
    }
    // public function makeapikey(Request $rq){
    //     $dbexcateto=$rq->datepushto;
    //     $dbexcateform=$rq->datepushform;
    //    // echo $dbexcateto;
    //    if(isset($dbexcateto) OR isset($dbexcateform)){
    //     $result=pomodel::where('date','>=',$dbexcateto)
    //     ->where('date','<=',$dbexcateform)
    //     ->get();
    //      echo 1;
    //    }
    //    else{
    //     $result=pomodel::get();
    //     echo 0;
    //    return view('reportdata.report');
    // echo  $result;
    //   }

    // }
}

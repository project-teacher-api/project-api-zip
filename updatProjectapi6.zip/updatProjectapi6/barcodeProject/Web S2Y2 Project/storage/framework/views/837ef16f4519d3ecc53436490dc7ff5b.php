<img  src="https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_92x30dp.png" alt="" <?php echo e($attributes); ?>>

>
<?php /**PATH D:\ProjectTeachterAPI\updatProjectapi5\barcodeProject\Web S2Y2 Project\resources\views/components/icodelinenew.blade.php ENDPATH**/ ?>
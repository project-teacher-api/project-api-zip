<?php echo e($slot); ?>

<?php /**PATH F:\ProjectTeacterSoven\updatProject3\barcodeProject\Web S2Y2 Project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
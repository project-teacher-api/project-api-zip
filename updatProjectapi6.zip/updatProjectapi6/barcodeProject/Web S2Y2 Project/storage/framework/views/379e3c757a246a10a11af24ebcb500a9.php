<?php echo e($slot); ?>

<?php /**PATH D:\ProjectTeachterAPI\updatProjectapi6\barcodeProject\Web S2Y2 Project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>
<table class="table table-bordered">
    <thead>
    <tr >
        <td>new</td>
        <td>new</td>
        <td>new</td>
        <td>new</td>
        <td>new</td>

    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $polist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
    <td><?php echo e($item->pocode); ?></td>
    <td><?php echo e($item->date); ?></td>
    <td><?php echo e($item->dis); ?></td>
    <td><?php echo e($item->tax); ?></td>
    <td><?php echo e($item->total); ?></td>
   </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody><?php /**PATH E:\ProjectTeachterAPI\updatProjectapi5\barcodeProject\Web S2Y2 Project\resources\views/components/table-search.blade.php ENDPATH**/ ?>
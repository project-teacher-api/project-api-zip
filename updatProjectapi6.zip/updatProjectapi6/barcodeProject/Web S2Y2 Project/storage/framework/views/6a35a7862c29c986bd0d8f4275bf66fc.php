
<img src="assets/img/profile-img.jpg" alt="" <?php echo e($attributes); ?>>
<?php /**PATH D:\ProjectTeachterAPI\updatProjectapi5\barcodeProject\Web S2Y2 Project\resources\views/components/application-logo.blade.php ENDPATH**/ ?>
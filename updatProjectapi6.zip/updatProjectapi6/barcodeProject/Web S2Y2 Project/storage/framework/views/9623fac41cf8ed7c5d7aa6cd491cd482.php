<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\ProjectTeachterAPI\updatProjectapi6\barcodeProject\Web S2Y2 Project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>
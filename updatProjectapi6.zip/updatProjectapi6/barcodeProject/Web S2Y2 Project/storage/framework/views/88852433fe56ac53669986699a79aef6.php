
<img src="assets/img/profile-img.jpg" alt="" <?php echo e($attributes); ?>>
<?php /**PATH F:\updatProject3\barcodeProject\Web S2Y2 Project\resources\views/components/application-logo.blade.php ENDPATH**/ ?>
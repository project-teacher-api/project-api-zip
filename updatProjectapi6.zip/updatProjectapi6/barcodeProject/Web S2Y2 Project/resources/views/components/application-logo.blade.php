
<img src="assets/img/profile-img.jpg" alt="" {{ $attributes }}>
